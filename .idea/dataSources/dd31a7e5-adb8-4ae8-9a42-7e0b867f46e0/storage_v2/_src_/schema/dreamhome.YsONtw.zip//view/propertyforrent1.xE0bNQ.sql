create definer = root@localhost view propertyforrent1 as
select `dreamhome`.`propertyforrent`.`PropertyNo` AS `PropertyNo`, `dreamhome`.`propertyforrent`.`city` AS `pCity`
from `dreamhome`.`propertyforrent`
where (`dreamhome`.`propertyforrent`.`PropertyNo` in ('PA14', 'PL94', 'PG4'));

