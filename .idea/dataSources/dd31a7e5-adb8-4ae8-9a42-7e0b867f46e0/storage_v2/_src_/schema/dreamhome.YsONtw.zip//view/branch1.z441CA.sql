create definer = root@localhost view branch1 as
select `dreamhome`.`branch`.`branchNo` AS `branchNo`, `dreamhome`.`branch`.`city` AS `bCity`
from `dreamhome`.`branch`
where (`dreamhome`.`branch`.`branchNo` in ('B003', 'B004', 'B002'));

